#!/bin/bash


eval "$(conda shell.bash hook)"

conda activate crux

chmod +x /mnt/crux.sh

/mnt/crux.sh -n 16S -f CGAGAAGACCCTATGGAGCT -r CCGAGGTCRCCCCAACC -s 30 -m 200 -e 3 -o 16S -d ./ -l

if [ -s /mnt/16S/16S_db_unfiltered/16S_fasta_and_taxonomy/16S_taxonomy.txt ]; then echo "unfiltered taxonomy not empty"; else echo "unfiltered taxonomy empty" && exit 1; fi

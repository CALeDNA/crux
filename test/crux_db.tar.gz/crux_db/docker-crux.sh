#!/bin/bash

source /usr/local/miniconda/etc/profile.d/conda.sh crux

# conda info | grep -i 'base environment'

conda activate crux

cd /mnt

chmod +x crux.sh

./crux.sh -n 16S -f CGAGAAGACCCTATGGAGCT -r CCGAGGTCRCCCCAACC -s 30 -m 200 -e 3 -o 16S -d ./ -l

if [ -s 16S/16S_db_unfiltered/16S_fasta_and_taxonomy/16S_taxonomy.txt ]; then echo "unfiltered taxonomy not empty"; else echo "unfiltered taxonomy empty" && exit 1; fi
